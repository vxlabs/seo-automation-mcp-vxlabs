=== SmartForms ===
Contributors: smartforms
Tags: forms, elementor, recaptcha, mcp, entries
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 0.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Build WordPress forms, manage entries, embed forms in Elementor, and process submissions through MCP.

== Description ==

SmartForms provides a field-based form builder, public shortcode and Elementor rendering, server-side validation, entry workflows, CSV export, configurable messages, Google reCAPTCHA, email notifications, and capability-checked MCP tools.

== Installation ==

1. Upload and activate SmartForms.
2. Go to SmartForms > Forms.
3. Create and publish a form.
4. Embed it using its shortcode or the SmartForms Elementor widget.

== Changelog ==

= 0.1.2 =
* Fixed access to the hidden form editor route after adding internal navigation tabs.

= 0.1.1 =
* Added persistent Dashboard, Forms, Entries, and Settings navigation inside SmartForms admin screens.

= 0.1.0 =
* Initial form builder and entry-management release.
* Added Google reCAPTCHA v2 checkbox, v2 invisible, and v3 verification.
* Added Elementor widget and shortcode renderer.
* Added capability-checked MCP form and entry tools through MCP Connector.
