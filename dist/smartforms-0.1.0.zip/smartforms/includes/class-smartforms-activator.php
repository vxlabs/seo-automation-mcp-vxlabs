<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SmartForms_Activator {

	public static function activate() {
		self::create_tables();
		self::add_capabilities();
		update_option( 'smartforms_db_version', SMARTFORMS_DB_VERSION, false );
		if ( false === get_option( 'smartforms_settings', false ) ) {
			add_option( 'smartforms_settings', SmartForms_Form_Repository::default_global_settings(), '', false );
		}
		if ( ! wp_next_scheduled( 'smartforms_daily_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'smartforms_daily_cleanup' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'smartforms_daily_cleanup' );
		// Entries and forms are deliberately retained on deactivation.
	}

	public static function maybe_upgrade() {
		if ( SMARTFORMS_DB_VERSION !== get_option( 'smartforms_db_version' ) ) {
			self::create_tables();
			self::add_capabilities();
			update_option( 'smartforms_db_version', SMARTFORMS_DB_VERSION, false );
		}
	}

	private static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$collate = $wpdb->get_charset_collate();
		$entries = $wpdb->prefix . 'smartforms_entries';
		$events  = $wpdb->prefix . 'smartforms_entry_events';

		$sql_entries = "CREATE TABLE {$entries} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT UNSIGNED NOT NULL,
			form_version BIGINT UNSIGNED NOT NULL DEFAULT 1,
			status VARCHAR(20) NOT NULL DEFAULT 'new',
			payload LONGTEXT NOT NULL,
			schema_snapshot LONGTEXT NOT NULL,
			source_url TEXT NULL,
			user_id BIGINT UNSIGNED NULL,
			ip_hash CHAR(64) NULL,
			user_agent VARCHAR(255) NULL,
			processed_by BIGINT UNSIGNED NULL,
			submitted_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY form_status (form_id, status),
			KEY submitted_at (submitted_at)
		) {$collate};";

		$sql_events = "CREATE TABLE {$events} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			entry_id BIGINT UNSIGNED NOT NULL,
			event_type VARCHAR(20) NOT NULL,
			old_status VARCHAR(20) NULL,
			new_status VARCHAR(20) NULL,
			note TEXT NULL,
			user_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY entry_id (entry_id),
			KEY created_at (created_at)
		) {$collate};";

		dbDelta( $sql_entries );
		dbDelta( $sql_events );
	}

	private static function add_capabilities() {
		$caps = array(
			'smartforms_manage_forms',
			'smartforms_view_entries',
			'smartforms_manage_entries',
			'smartforms_manage_settings',
			'smartforms_delete_entries',
		);

		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( $caps as $cap ) {
				$admin->add_cap( $cap );
			}
		}

		$manager = get_role( 'smartforms_manager' );
		if ( ! $manager ) {
			$manager = add_role( 'smartforms_manager', 'SmartForms Manager', array( 'read' => true ) );
		}
		if ( $manager ) {
			foreach ( array_slice( $caps, 0, 3 ) as $cap ) {
				$manager->add_cap( $cap );
			}
		}
	}
}
