<?php
/**
 * Run inside an installed WordPress instance with:
 * wp eval-file wp-content/plugins/smartforms/tests/integration-smoke.php
 */

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	throw new RuntimeException( 'This smoke test must be run through WP-CLI.' );
}

wp_set_current_user( 1 );

$tools = Mcp_Tool_Registry::get_definitions();
$names = wp_list_pluck( $tools, 'name' );
if ( ! in_array( 'smartforms_list_entries', $names, true ) ) {
	throw new RuntimeException( 'SmartForms MCP tools were not registered.' );
}

$blank_schema = SmartForms_Form_Repository::default_schema();
if ( ! empty( $blank_schema['fields'] ) ) {
	throw new RuntimeException( 'New forms should start with an empty field canvas.' );
}

$test_schema = array(
	'version' => 1,
	'fields'  => array(
		SmartForms_Field_Registry::default_field( 'text' ),
		SmartForms_Field_Registry::default_field( 'email' ),
		SmartForms_Field_Registry::default_field( 'textarea' ),
		SmartForms_Field_Registry::default_field( 'button' ),
	),
);
$created = SmartForms_Form_Repository::create( 'SmartForms Smoke Test', $test_schema, null, 'publish' );
if ( is_wp_error( $created ) ) {
	throw new RuntimeException( $created->get_error_message() );
}

$fields = array();
foreach ( $created['schema']['fields'] as $field ) {
	if ( 'text' === $field['type'] ) {
		$fields[ $field['id'] ] = 'Test Person';
	} elseif ( 'email' === $field['type'] ) {
		$fields[ $field['id'] ] = 'test@example.com';
	} elseif ( 'textarea' === $field['type'] ) {
		$fields[ $field['id'] ] = 'This is an integration smoke test.';
	}
}

$request = new WP_REST_Request( 'POST', '/smartforms/v1/forms/' . $created['id'] . '/submit' );
$request->set_body_params(
	array(
		'form_token'     => SmartForms_Renderer::token( $created ),
		'form_started'   => time() - 3,
		'company_website'=> '',
		'source_url'     => home_url( '/smoke-test' ),
		'fields'         => $fields,
	)
);

$submitted = SmartForms_Submission_Service::submit( $created['id'], $request );
if ( is_wp_error( $submitted ) || empty( $submitted['entry_id'] ) ) {
	$message = is_wp_error( $submitted ) ? $submitted->get_error_message() : 'Entry was not created.';
	throw new RuntimeException( $message );
}

$html = SmartForms_Renderer::render( $created['id'] );
if ( false === strpos( $html, 'smartforms-form' ) ) {
	throw new RuntimeException( 'Published form did not render.' );
}

global $wpdb;
$wpdb->delete( SmartForms_Entry_Repository::events_table(), array( 'entry_id' => $submitted['entry_id'] ), array( '%d' ) );
$wpdb->delete( SmartForms_Entry_Repository::table(), array( 'id' => $submitted['entry_id'] ), array( '%d' ) );
wp_delete_post( $created['id'], true );

WP_CLI::success( 'SmartForms form creation, rendering, submission storage, and MCP registration passed.' );
